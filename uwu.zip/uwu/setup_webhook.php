<?php
require_once 'config.php';
global $botToken;

// Get the webhook URL from Replit environment
$webhookUrl = getenv('REPL_URL') . '/';
if (!$webhookUrl || $webhookUrl === '/') {
    die("Error: REPL_URL environment variable not set. Please deploy the bot first.\n");
}

// Set webhook
$url = "https://api.telegram.org/bot$botToken/setWebhook?url=" . urlencode($webhookUrl);
$response = file_get_contents($url);
$result = json_decode($response, true);

if ($result['ok']) {
    echo "✅ Webhook set successfully!\n";
    echo "Webhook URL: $webhookUrl\n";
    echo "Description: " . $result['description'] . "\n";
} else {
    echo "❌ Failed to set webhook: " . $result['description'] . "\n";
}

// Get webhook info
$infoUrl = "https://api.telegram.org/bot$botToken/getWebhookInfo";
$infoResponse = file_get_contents($infoUrl);
$infoResult = json_decode($infoResponse, true);

if ($infoResult['ok']) {
    echo "\n📋 Current webhook info:\n";
    echo "URL: " . $infoResult['result']['url'] . "\n";
    echo "Has custom certificate: " . ($infoResult['result']['has_custom_certificate'] ? 'Yes' : 'No') . "\n";
    echo "Pending update count: " . $infoResult['result']['pending_update_count'] . "\n";
    if (isset($infoResult['result']['last_error_message'])) {
        echo "Last error: " . $infoResult['result']['last_error_message'] . "\n";
    }
}
?>