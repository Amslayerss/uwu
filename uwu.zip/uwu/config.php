<?php
// Bot Configuration
$botToken = getenv('BOT_TOKEN') ?: '7985047916:AAE-_QwQQxygDAGV65qsPeRDBb78LmLEqo4';
$website = "https://api.telegram.org/bot" . $botToken;

// Database configuration is handled via file system
// All user data is stored in Database/*.txt files

// Set timezone
date_default_timezone_set('UTC');

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', TRUE);
ini_set('error_log', 'errors.log');
?>