# Overview

This repository contains a Telegram bot system for credit card BIN (Bank Identification Number) validation and generation services. The bot provides premium and free access tiers for users to validate credit card information, generate test card numbers, and manage user subscriptions. The system appears to be designed for educational or testing purposes related to payment processing validation.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Bot Architecture
The system is built as a Telegram bot that handles user interactions through chat commands. The bot manages user authentication, subscription verification, and provides different service tiers based on user status (free, premium, owner).

## Data Storage Design
The application uses a file-based data storage system with the following components:

- **User Management**: Separate text files track different user categories (free users, premium subscribers, paid users, owners)
- **BIN Cache System**: Individual cache files store recently used BIN patterns for each user ID, enabling quick lookup and history tracking
- **Subscription Management**: Premium subscriptions include expiration dates, while free users are tracked without time limits
- **Code System**: Activation codes are managed through a dedicated file with usage tracking

## Authentication & Authorization
The system implements a multi-tier access control:

- **Owner Level**: Full administrative access (stored in owner.txt)
- **Premium Users**: Extended features with expiration dates (Premium.txt, paid.txt)
- **Free Users**: Basic access with limitations (free.txt)
- **Group Management**: Telegram group IDs for bot deployment (gp.txt)

## BIN Processing Logic
The core functionality revolves around credit card BIN validation and generation:

- **User-Specific Caching**: Each user maintains their own BIN history in separate cache files
- **Pattern Recognition**: The system stores and retrieves card number patterns, expiration dates, and CVV codes
- **Format Standardization**: Card data is stored in consistent formats with masked numbers for security

## Session Management
The system tracks user sessions and maintains state through:

- **Cookie Storage**: Web session cookies are preserved for external service integration
- **Cache Persistence**: User-specific BIN caches maintain service continuity
- **Group Context**: Bot operates within specific Telegram groups for controlled access

# External Dependencies

## Telegram Bot API
The system integrates with Telegram's Bot API for all user interactions, command processing, and message handling. This provides the primary interface for users to access BIN validation services.

## File System Storage
All data persistence relies on the local file system with structured text files for user data, caches, and configuration. This approach provides simplicity but may require migration to a database system for scalability.

## External Payment Services
Based on the cookie files, the system appears to integrate with various e-commerce platforms including Shopify-based stores (Vanguard Military, Ryderwear, Sprayer Depot) and payment processors like PayPal for validation testing purposes.

## Web Session Management
The application maintains web session cookies for external service integration, suggesting it can simulate or test real payment flows across different merchant platforms.