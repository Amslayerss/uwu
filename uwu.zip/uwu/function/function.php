<?php

function send_reply($chatId, $message_id, $keyboard, $message) {
    global $botToken;
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $params = [
        'chat_id' => $chatId,
        'text' => $message,
        'reply_to_message_id' => $message_id,
        'parse_mode' => 'HTML'
    ];
    
    if ($keyboard) {
        $params['reply_markup'] = $keyboard;
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    
    if ($response === FALSE) {
        error_log("Failed to send message");
        return null;
    }
    
    $result = json_decode($response, TRUE);
    return isset($result['result']['message_id']) ? $result['result']['message_id'] : null;
}

function edit_sent_message($chatId, $message_id, $message) {
    global $botToken;
    $url = "https://api.telegram.org/bot$botToken/editMessageText";
    $params = [
        'chat_id' => $chatId,
        'message_id' => $message_id,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    if ($response === FALSE) {
        error_log("Failed to edit message");
    }
    return $response;
}


function checkAccess($userid) {
    $usersPaid = file("Database/Premium.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $usersOwner = file("Database/owner.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    
  $allUsers = array_merge($usersPaid, $usersOwner);
    foreach($allUsers as $user) {
        $parts = explode(" ", $user);
        $userIdFromFile = $parts[0];

        if($userid == $userIdFromFile) {
            return true;
        }
    }
    return false;
}

function editMessagei($chatId, $message, $message_id) {
    global $botToken;
    $url = "https://api.telegram.org/bot$botToken/editMessageText";
    $params = [
        'chat_id' => $chatId,
        'message_id' => $message_id,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);
    
    return $result;
}






