<?php

// This file is included from index.php, ensure variables are available
global $text, $chatId, $messageId, $userId, $username, $botToken;

if (!isset($text) || !isset($chatId) || !isset($messageId)) {
    return;
}

// Check if user has access (registered at least as free user)
$users = file_get_contents('Database/free.txt');
$freeusers = explode("\n", $users);

//=========START END========//
if (preg_match('/^(\/start|\.cmds|!cmds)/', $text)) {
    
    $videoUrl = "https://t.me/DartNetc/22"; 

    $keyboard2 = json_encode([
        'inline_keyboard' => [
           [
               ["text" => "𝙂𝙖𝙩𝙚𝙬𝙖𝙮𝙨 ⚓", "callback_data" => "gates"],
               ["text" => "𝘾𝙡𝙤𝙨𝙚 🔒", "callback_data" => "price"]
           ],
           [
               ["text" => "𝙊𝙩𝙝𝙚𝙧 𝙏𝙤𝙤𝙡𝙨 🧰", "callback_data" => "herr"],
               ['text' => '[🜲] 𝙊𝙬𝙣𝙚𝙧', 'url' => 'https://t.me/wowfox9']
           ],
           [
               ['text' => ' 𝗟𝗮𝗳𝗮 (𝗚𝗨𝗜𝗔) ', 'url' => 'https://t.me/lafacheck']
           ]
        ]
    ]);

    $caption = "𝐇𝐞𝐥𝐥𝐨, 𝐓𝐨 𝐤𝐧𝐨𝐰 𝐦𝐲 𝐜𝐨𝐦𝐦𝐚𝐧𝐝𝐬 𝐩𝐫𝐞𝐬𝐬 𝐚𝐧𝐲 𝐨𝐟 𝐭𝐡𝐞 𝐛𝐮𝐭𝐭𝐨𝐧𝐬❗ ";
    
    // Delete the user's message
    global $botToken;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://api.telegram.org/bot$botToken/deleteMessage");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, [
        'chat_id' => $chatId,
        'message_id' => $messageId
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);

    // Send video with inline keyboard
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://api.telegram.org/bot$botToken/sendVideo");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, [
        'chat_id' => $chatId,
        'video' => $videoUrl,
        'caption' => $caption,
        'parse_mode' => 'HTML',
        'reply_markup' => $keyboard2
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);
}