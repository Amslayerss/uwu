<?php
// This file is included from index.php, ensure variables are available
global $message, $userId, $chatId, $messageId;

if (isset($message) && preg_match('/\/register/', $message)) {
    // Load the existing users.
    $users = file_get_contents('Database/free.txt');
    $freeusers = explode("\n", $users);

    // Check if the user has already registered.
    if (isset($userId) && in_array($userId, $freeusers)) {
        $response = 'User already registered ❌';
    } else {
        // If not, add the user to the file.
        if (isset($userId)) {
            $file = fopen('Database/free.txt', 'a');
            fwrite($file, $userId . "\n");
            fclose($file);
        }

        $response = 'User registered successfully ✅!Now click /start';
    }

    // Send the response.
    if (isset($chatId) && function_exists('reply_tox')) {
        reply_tox($chatId, $messageId ?? 0, '', $response);
    }
}
?>
