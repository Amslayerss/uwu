<?php
// Telegram Bot Webhook Handler
require_once 'config.php';

// Helper function to send message
function sendMessage($chatId, $message, $messageId = null) {
    global $botToken;
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $params = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];
    
    if ($messageId) {
        $params['reply_to_message_id'] = $messageId;
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);
    
    return $result;
}

// Helper function to edit message
function editMessage($chatId, $messageId, $text) {
    global $botToken;
    $url = "https://api.telegram.org/bot$botToken/editMessageText";
    $params = [
        'chat_id' => $chatId,
        'message_id' => $messageId,
        'text' => $text,
        'parse_mode' => 'HTML'
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);
    
    return $result;
}

// Helper function for reply_tox (used in register.php)
function reply_tox($chatId, $messageId, $keyboard, $message) {
    global $botToken;
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $params = [
        'chat_id' => $chatId,
        'text' => $message,
        'reply_to_message_id' => $messageId,
        'parse_mode' => 'HTML'
    ];
    
    if ($keyboard) {
        $params['reply_markup'] = $keyboard;
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);
    
    return $result;
}

// Helper function to handle callback queries
function handleCallbackQuery($callback_data, $chatId, $messageId, $userId) {
    global $botToken;
    
    switch($callback_data) {
        case 'gates':
            $gateList = "
<b>Available Gateways:</b>

• <code>/ss</code> - Stripe Auth
• <code>/adyen</code> - Adyen Auth  
• <code>/bt</code> - Braintree Auth
• <code>/btavs</code> - Braintree AVS
• <code>/pp</code> - PayPal 0.01$
• <code>/sq</code> - Square Auth
• <code>/shop</code> - Shopify 12$

<i>Use any command above to check cards</i>";
            
            editMessage($chatId, $messageId, $gateList);
            break;
            
        case 'price':
            editMessage($chatId, $messageId, "<b>Bot Closed ❌</b>");
            break;
            
        case 'herr':
            $otherTools = "
<b>Other Tools:</b>

• <code>/register</code> - Register as free user
• <code>/redeem [code]</code> - Redeem premium code
• <code>/credits</code> - Check your status
• <code>/users</code> - User statistics (Owner only)

<i>Contact owner for premium access</i>";
            
            editMessage($chatId, $messageId, $otherTools);
            break;
    }
}

// Include required functions
require_once 'function/function.php';
require_once 'function/database.php';
require_once 'function/antispam.php';

// Get webhook input
$update = json_decode(file_get_contents("php://input"), TRUE);

if (!$update) {
    http_response_code(200);
    exit("Bot is running...");
}

// Extract message data
$message = isset($update["message"]["text"]) ? $update["message"]["text"] : "";
$text = $message;
$chatId = isset($update["message"]["chat"]["id"]) ? $update["message"]["chat"]["id"] : "";
$messageId = isset($update["message"]["message_id"]) ? $update["message"]["message_id"] : "";
$userId = isset($update["message"]["from"]["id"]) ? $update["message"]["from"]["id"] : "";
$username = isset($update["message"]["from"]["username"]) ? $update["message"]["from"]["username"] : "";
$firstname = isset($update["message"]["from"]["first_name"]) ? $update["message"]["from"]["first_name"] : "";

// Handle callback queries
if (isset($update['callback_query'])) {
    $callback_data = $update['callback_query']['data'];
    $chatId = $update['callback_query']['message']['chat']['id'];
    $messageId = $update['callback_query']['message']['message_id'];
    $userId = $update['callback_query']['from']['id'];
    $username = isset($update['callback_query']['from']['username']) ? $update['callback_query']['from']['username'] : "";
    
    // Handle callback queries
    handleCallbackQuery($callback_data, $chatId, $messageId, $userId);
}

// Handle text messages
if ($message) {
    // Include and handle various commands
    include 'function/cmdsstart.php';
    include 'function/register.php';
    include 'function/redeem.php';
    include 'function/credits.php';
    include 'function/code.php';
    include 'function/remexp.php';
    include 'function/users.php';
    include 'admin/admincmd.php';
    
    // Handle gateway commands
    if (preg_match('/^(\/ss|\.ss|!ss)/', $text)) {
        include 'gates/StripeAuth.php';
    }
    if (preg_match('/^(\/adyen|\.adyen|!adyen)/', $text)) {
        include 'gates/AdyenAuth.php';
    }
    if (preg_match('/^(\/bt|\.bt|!bt)/', $text)) {
        include 'gates/BraintreeAuth.php';
    }
    if (preg_match('/^(\/btavs|\.btavs|!btavs)/', $text)) {
        include 'gates/BraintreeAvs.php';
    }
    if (preg_match('/^(\/pp|\.pp|!pp)/', $text)) {
        include 'gates/PayPal0.01$.php';
    }
    if (preg_match('/^(\/sq|\.sq|!sq)/', $text)) {
        include 'gates/SquareAuth.php';
    }
    if (preg_match('/^(\/shop|\.shop|!shop)/', $text)) {
        include 'gates/Shopfiy12$.php';
    }
}

// Send response
http_response_code(200);
?>